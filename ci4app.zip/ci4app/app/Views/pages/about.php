<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae nemo omnis temporibus magni inventore minima aliquid possimus deserunt eligendi harum! Adipisci, nemo? Saepe illum accusamus doloremque quod voluptatibus fuga quibusdam?</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>